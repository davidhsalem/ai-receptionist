import express from "express";
import OpenAI from "openai";
import fs from "fs";

const app = express();
app.use(express.json({ limit: "64kb" }));
app.use(express.static("public"));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const skill = fs.readFileSync("./SKILL.md", "utf8");

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim().slice(0, 3000);
    if (!message) return res.status(400).json({ error: "Message required" });

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6",
      instructions: skill,
      input: message
    });

    res.json({ reply: response.output_text || "Please contact the Dr Botoxo team for assistance." });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Receptionist temporarily unavailable." });
  }
});

app.get("/health", (_, res) => res.json({ ok: true }));
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Dr Botoxo receptionist listening on ${port}`));
