# Dr Botoxo AI Receptionist

Deployable starter for the Dr Botoxo website receptionist.

## Files
- `SKILL.md` — receptionist behaviour and safety rules
- `server.js` — secure server-side AI endpoint
- `public/index.html` — mobile-friendly chat interface

## Deploy
1. Upload these files to your private GitHub `ai-receptionist` repository.
2. Connect the repository to your hosting provider.
3. Add `OPENAI_API_KEY` as a server-side secret/environment variable. Never put it in GitHub code or the browser.
4. Start command: `npm start`.
5. Confirm `/health` returns `{"ok":true}`.
6. Test medical escalation, booking confirmation, privacy and human handoff before publishing.
7. Embed/link the deployed receptionist from drbotoxo.clinic.

This starter intentionally does not store CRM records yet. Add a database only after defining consent, staff access, retention/deletion and booking integrations.
